for word; do
  echo $word
  sleep 1
done
