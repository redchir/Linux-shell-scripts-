#!/bin/bash

animalTypes="gecko and hamster"
LOCATION="Utrecht"
name="Sebastiaan"
home_type="house"
_partner_name="Sanne"

# Print the story.
echo "${name} lives in a ${home_type} in ${LOCATION}, together with ${_partner_name} and their two pets: a ${animalTypes}."
